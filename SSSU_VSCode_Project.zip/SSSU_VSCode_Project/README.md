# SSSU Student Support Agent

A demonstration student-support application built with Streamlit, Groq tool calling, SQLite, ChromaDB and PDF-based retrieval-augmented generation (RAG).

> **Academic prototype notice:** The bundled handbook policies, fee figures, scholarships and demo student are illustrative only. They are not official university policy or real student data.

## Requirements
- Python 3.10 or 3.11 recommended
- A Groq API key for live AI responses
- Internet access for first-time package/model downloads

## Run in VS Code (Windows)
1. Extract this folder and open it in VS Code: **File → Open Folder**.
2. Open **Terminal → New Terminal**.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, use Command Prompt terminal and run `.venv\Scripts\activate.bat`.
4. Install dependencies:
   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
5. Create your private environment file:
   ```powershell
   Copy-Item .env.example .env
   ```
   Open `.env` and replace the placeholder with your own Groq API key and a strong admin password. Never share or commit `.env`.
6. Create the sample handbook PDF and initialize databases. In the VS Code terminal run:
   ```powershell
   python setup_project.py
   ```
7. Start the app:
   ```powershell
   python -m streamlit run app.py
   ```
8. Open the local URL printed in the terminal, usually http://localhost:8501.

## Demo student
- Username: `demo`
- Password: `Demo@12345`

Change or remove demo credentials before any real deployment.

## Project files
- `app.py`: Streamlit interface and student/admin workflows
- `agent.py`: Groq agent orchestration, tool calls, latency and token metrics
- `tools.py`: fee, scholarship, handbook and profile-update tools
- `database.py`: SQLite authentication, student records, approval queue and audit log
- `memory.py`: student preference memory and sensitive-data filtering
- `rag.py`: handbook PDF extraction, embeddings and ChromaDB retrieval
- `setup_project.py`: generates the illustrative handbook and initializes databases

## Security and limitations
This is an academic prototype, not a production student information system. Use synthetic data only. The demo admin login, SQLite storage, audit-chain design and application security require independent review before real institutional use. Do not upload `.env`, database files, vector-store files, API keys, or real student data.
