import os
import json
import time

from dotenv import load_dotenv
from groq import Groq

from tools import TOOL_SCHEMAS, execute_tool
from memory import get_student_memories

load_dotenv()

SYSTEM_PROMPT = """
You are the Satya Sanatan Sanskrit University
Student Support AI Assistant.

Your responsibilities:

1. Help students with fee-related questions.
2. Explain scholarship information.
3. Answer university policy questions.
4. Help with student profile requests.
5. Protect student privacy.

Security rules:

- Never reveal another student's information.
- Use tools for fee and scholarship queries.
- Use the handbook tool for university policy questions.
- Never invent university policies.
- Profile changes require administrator approval.
- Never request or store OTPs, passwords or PINs.
- Cite handbook page labels when answering policy questions.
"""


def run_agent_turn(student_data, messages):

    start_time = time.time()

    client = Groq(
        api_key=os.getenv("GROQ_API_KEY")
    )

    model = os.getenv(
        "GROQ_MODEL",
        "openai/gpt-oss-120b"
    )

    memories = get_student_memories(
        student_data["student_id"]
    )

    student_context = {
        "student_id": student_data["student_id"],
        "full_name": student_data["full_name"],
        "program": student_data["program"],
        "preferences": memories
    }

    system_message = SYSTEM_PROMPT + "\n\nACTIVE STUDENT:\n" + json.dumps(student_context)

    conversation = [
        {"role": "system", "content": system_message}
    ]

    for message in messages[-30:]:

        if message["role"] in ["user", "assistant"]:
            conversation.append(message)

    traces = []

    prompt_tokens = 0
    completion_tokens = 0
    total_tokens = 0

    # FIRST LLM CALL

    response = client.chat.completions.create(
        model=model,
        messages=conversation,
        tools=TOOL_SCHEMAS,
        tool_choice="auto",
        temperature=0.2
    )

    usage = response.usage

    if usage:
        prompt_tokens += usage.prompt_tokens
        completion_tokens += usage.completion_tokens
        total_tokens += usage.total_tokens

    assistant_message = response.choices[0].message

    # TOOL EXECUTION

    if assistant_message.tool_calls:

        conversation.append({
            "role": "assistant",
            "content": assistant_message.content or "",
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments
                    }
                }
                for tc in assistant_message.tool_calls
            ]
        })

        for tool_call in assistant_message.tool_calls:

            tool_name = tool_call.function.name

            try:
                arguments = json.loads(
                    tool_call.function.arguments
                )
            except Exception:
                arguments = {}

            result = execute_tool(
                tool_name,
                arguments,
                student_data["student_id"]
            )

            traces.append({
                "tool": tool_name,
                "input": arguments,
                "output": result
            })

            conversation.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": tool_name,
                "content": json.dumps(result)
            })

        # SECOND LLM CALL

        final_response = client.chat.completions.create(
            model=model,
            messages=conversation,
            temperature=0.2
        )

        usage = final_response.usage

        if usage:
            prompt_tokens += usage.prompt_tokens
            completion_tokens += usage.completion_tokens
            total_tokens += usage.total_tokens

        final_text = (
            final_response.choices[0].message.content
            or "I could not generate a response."
        )

    else:

        final_text = assistant_message.content or ""

    latency = round(time.time() - start_time, 3)

    metrics = {
        "latency_seconds": latency,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
        "traces": traces
    }

    return final_text, metrics