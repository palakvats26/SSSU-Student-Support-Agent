import json

from database import (
    get_student_by_id,
    log_audit,
    create_pending_action
)


TOOL_SCHEMAS = [

    {
        "type": "function",
        "function": {
            "name": "get_student_fee_status",
            "description": "Get the authenticated student's fee status.",
            "parameters": {
                "type": "object",
                "properties": {
                    "target_student_id": {"type": "string"}
                },
                "required": ["target_student_id"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "get_scholarship_details",
            "description": "Get the authenticated student's scholarship details.",
            "parameters": {
                "type": "object",
                "properties": {
                    "target_student_id": {"type": "string"}
                },
                "required": ["target_student_id"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "request_profile_update",
            "description": "Request an administrative update to registered bank or phone.",
            "parameters": {
                "type": "object",
                "properties": {
                    "attribute": {
                        "type": "string",
                        "enum": [
                            "registered_phone",
                            "registered_bank"
                        ]
                    },
                    "new_value": {"type": "string"}
                },
                "required": ["attribute", "new_value"]
            }
        }
    },

    {
        "type": "function",
        "function": {
            "name": "query_university_handbook",
            "description": "Search the university handbook.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"}
                },
                "required": ["query"]
            }
        }
    }
]


def execute_tool(tool_name, args, authenticated_student_id):

    # TOOL 1: FEE STATUS

    if tool_name == "get_student_fee_status":

        target = args.get("target_student_id")

        if target != authenticated_student_id:

            log_audit(
                authenticated_student_id,
                tool_name,
                target,
                "BLOCKED",
                "Unauthorized student record access"
            )

            return {
                "error": "ACCESS_DENIED: You cannot inspect records belonging to other students."
            }

        student = get_student_by_id(authenticated_student_id)

        if not student:
            return {"error": "Student not found"}

        result = {
            "student_id": student["student_id"],
            "fee_due": student["fee_due"],
            "fee_status": student["fee_status"]
        }

        log_audit(
            authenticated_student_id,
            tool_name,
            target,
            "ALLOWED",
            json.dumps(result)
        )

        return result

    # TOOL 2: SCHOLARSHIP

    if tool_name == "get_scholarship_details":

        target = args.get("target_student_id")

        if target != authenticated_student_id:

            log_audit(
                authenticated_student_id,
                tool_name,
                target,
                "BLOCKED",
                "Unauthorized scholarship lookup"
            )

            return {
                "error": "ACCESS_DENIED: You cannot inspect another student's scholarship."
            }

        student = get_student_by_id(authenticated_student_id)

        result = {
            "scholarship_name": student["scholarship_name"],
            "scholarship_status": student["scholarship_status"]
        }

        log_audit(
            authenticated_student_id,
            tool_name,
            target,
            "ALLOWED",
            json.dumps(result)
        )

        return result

    # TOOL 3: PROFILE UPDATE

    if tool_name == "request_profile_update":

        attribute = args.get("attribute")
        new_value = str(args.get("new_value", "")).strip()

        if attribute not in [
            "registered_phone",
            "registered_bank"
        ] or not new_value:

            log_audit(
                authenticated_student_id,
                tool_name,
                authenticated_student_id,
                "BLOCKED",
                "Invalid profile update request"
            )

            return {"error": "Invalid profile update request"}

        if len(new_value) > 200:

            return {"error": "Proposed value is too long"}

        action_id = create_pending_action(
            authenticated_student_id,
            attribute,
            json.dumps({"new_value": new_value})
        )

        log_audit(
            authenticated_student_id,
            tool_name,
            authenticated_student_id,
            "PENDING_APPROVAL",
            f"Action ID: {action_id}"
        )

        return {
            "status": "REQUIRES_APPROVAL",
            "action_id": action_id,
            "message": "Sensitive modification detected. Requires human administrator approval."
        }

    # TOOL 4: HANDBOOK RAG

    if tool_name == "query_university_handbook":

        from rag import query_handbook

        result = query_handbook(args.get("query", ""))

        log_audit(
            authenticated_student_id,
            tool_name,
            "handbook",
            "ALLOWED",
            "Handbook retrieval successful"
        )

        return {"handbook_excerpts": result}

    return {"error": "Unknown tool"}