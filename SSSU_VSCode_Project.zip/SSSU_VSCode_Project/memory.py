import sqlite3
import re
from datetime import datetime, timezone

MEMORY_DB = "sssu_memory.db"

OTP_PATTERN = re.compile(r"\b\d{4,8}\b")

SECRET_PATTERN = re.compile(
    r"(?i)\b(password|pwd|pin)\s*[:=]\s*\S+"
)


def scrub_sensitive_tokens(text):

    text = str(text)

    text = OTP_PATTERN.sub("[REDACTED_OTP]", text)

    text = SECRET_PATTERN.sub(
        lambda m: m.group(1) + "=[REDACTED_SECRET]",
        text
    )

    return text


def contains_sensitive_tokens(text):

    return bool(
        OTP_PATTERN.search(str(text))
        or SECRET_PATTERN.search(str(text))
    )


def init_memory_db():

    with sqlite3.connect(MEMORY_DB) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS long_term_memory (
                student_id TEXT,
                key TEXT,
                value TEXT,
                updated_at TEXT,
                PRIMARY KEY(student_id, key)
            )
        """)


def store_student_preference(student_id, key, value):

    init_memory_db()

    if contains_sensitive_tokens(key) or contains_sensitive_tokens(value):
        return False

    if not student_id or not key.strip() or not value.strip():
        return False

    with sqlite3.connect(MEMORY_DB) as conn:
        conn.execute("""
            INSERT INTO long_term_memory
            VALUES (?, ?, ?, ?)
            ON CONFLICT(student_id, key)
            DO UPDATE SET
            value=excluded.value,
            updated_at=excluded.updated_at
        """, (
            student_id,
            key.strip(),
            value.strip(),
            datetime.now(timezone.utc).isoformat()
        ))

    return True


def get_student_memories(student_id):

    init_memory_db()

    with sqlite3.connect(MEMORY_DB) as conn:
        rows = conn.execute("""
            SELECT key, value
            FROM long_term_memory
            WHERE student_id=?
        """, (student_id,)).fetchall()

    return dict(rows)