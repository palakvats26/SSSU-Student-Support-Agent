import streamlit as st
import json
import os
import hmac

from dotenv import load_dotenv

from database import (
    init_db,
    authenticate_student,
    register_student,
    get_student_by_id,
    get_pending_actions,
    review_pending_action,
    get_recent_audit_logs
)

from memory import (
    init_memory_db,
    store_student_preference,
    get_student_memories
)

from agent import run_agent_turn


load_dotenv()

st.set_page_config(
    page_title="SSSU Student Support",
    page_icon="🎓",
    layout="wide"
)

init_db()
init_memory_db()


# SESSION STATE

if "student" not in st.session_state:
    st.session_state.student = None

if "messages" not in st.session_state:
    st.session_state.messages = []

if "metrics" not in st.session_state:
    st.session_state.metrics = {}

if "is_admin" not in st.session_state:
    st.session_state.is_admin = False


# CUSTOM DESIGN

st.markdown("""
<style>

.main {
    background-color: #f7f8fc;
}

h1 {
    color: #172554;
}

.pill {
    padding: 5px 10px;
    border-radius: 12px;
    font-weight: bold;
}

.ALLOWED {
    background-color: #dcfce7;
    color: #166534;
}

.BLOCKED {
    background-color: #fee2e2;
    color: #991b1b;
}

.PENDING_APPROVAL {
    background-color: #fef3c7;
    color: #92400e;
}

</style>
""", unsafe_allow_html=True)


# AUTHENTICATION PAGE

def authentication_page():

    st.title("🎓 Satya Sanatan Sanskrit University")

    st.subheader("Student Support Portal")

    login_tab, register_tab = st.tabs([
        "Student Login",
        "Register"
    ])

    with login_tab:

        with st.form("login_form"):

            username = st.text_input("Username")

            password = st.text_input(
                "Password",
                type="password"
            )

            submit = st.form_submit_button("Login")

        if submit:

            user = authenticate_student(
                username,
                password
            )

            if user:

                st.session_state.student = user
                st.session_state.messages = []

                st.rerun()

            else:
                st.error("Invalid username or password.")

        st.caption(
            "Demo login: demo / Demo@12345"
        )

    with register_tab:

        with st.form("registration_form"):

            full_name = st.text_input("Full Name")

            student_id = st.text_input("Student ID")

            new_username = st.text_input("Username")

            new_password = st.text_input(
                "Password",
                type="password"
            )

            program = st.selectbox(
                "Program",
                ["Shastri", "Acharya", "PGDM"]
            )

            phone = st.text_input("Registered Phone")

            submit = st.form_submit_button("Create Account")

        if submit:

            try:

                register_student(
                    student_id,
                    new_username,
                    new_password,
                    full_name,
                    program,
                    phone
                )

                st.success(
                    "Registration successful. Please login."
                )

            except Exception as error:

                st.error(str(error))


if not st.session_state.student:

    authentication_page()

    st.stop()


# AUTHENTICATED STUDENT

student = get_student_by_id(
    st.session_state.student["student_id"]
)

if not student:

    st.session_state.student = None

    st.rerun()


# SIDEBAR

with st.sidebar:

    st.title("SSSU Operations")

    st.subheader("Student Identity")

    st.write("**Name:**", student["full_name"])

    st.write("**Student ID:**")

    st.code(student["student_id"])

    st.write("**Program:**", student["program"])

    st.divider()

    # MEMORY HUB

    st.subheader("🧠 Memory Hub")

    with st.form("memory_form"):

        memory_key = st.text_input(
            "Preference Name"
        )

        memory_value = st.text_area(
            "Preference Value"
        )

        save = st.form_submit_button(
            "Save Preference"
        )

    if save:

        result = store_student_preference(
            student["student_id"],
            memory_key,
            memory_value
        )

        if result:
            st.success("Preference saved.")
        else:
            st.error(
                "Sensitive information detected. Memory rejected."
            )

    memories = get_student_memories(
        student["student_id"]
    )

    if memories:

        with st.expander("Saved Preferences"):

            for key, value in memories.items():

                st.write(f"**{key}**")

                st.caption(value)

    st.divider()

    # ADMIN APPROVAL

    st.subheader("🛡️ Administrator Access")

    if not st.session_state.is_admin:

        with st.form("admin_login"):

            admin_user = st.text_input(
                "Admin Username"
            )

            admin_pass = st.text_input(
                "Admin Password",
                type="password"
            )

            admin_submit = st.form_submit_button(
                "Unlock Approval Queue"
            )

        if admin_submit:

            expected_user = os.getenv(
                "SSSU_ADMIN_USERNAME", ""
            )

            expected_pass = os.getenv(
                "SSSU_ADMIN_PASSWORD", ""
            )

            if (
                expected_pass
                and hmac.compare_digest(admin_user, expected_user)
                and hmac.compare_digest(admin_pass, expected_pass)
            ):

                st.session_state.is_admin = True

                st.rerun()

            else:

                st.error("Administrator authentication failed.")

    else:

        st.success("Administrator authenticated.")

        if st.button("Lock Administrator"):

            st.session_state.is_admin = False

            st.rerun()

        st.subheader("Pending Approval Queue")

        pending = get_pending_actions()

        if not pending:

            st.caption("No pending requests.")

        for action in pending:

            with st.container(border=True):

                st.warning(
                    f"Request #{action['action_id']}"
                )

                st.write(
                    "Student:", action["student_id"]
                )

                st.write(
                    "Attribute:", action["action_type"]
                )

                proposed = json.loads(
                    action["proposed_value"]
                )["new_value"]

                st.write("Proposed value:", proposed)

                col1, col2 = st.columns(2)

                if col1.button(
                    "Approve",
                    key=f"approve_{action['action_id']}"
                ):

                    review_pending_action(
                        action["action_id"],
                        "APPROVED",
                        reviewer=os.getenv(
                            "SSSU_ADMIN_USERNAME", "ADMIN"
                        )
                    )

                    st.success("Request approved.")

                    st.rerun()

                if col2.button(
                    "Reject",
                    key=f"reject_{action['action_id']}"
                ):

                    review_pending_action(
                        action["action_id"],
                        "REJECTED",
                        reviewer=os.getenv(
                            "SSSU_ADMIN_USERNAME", "ADMIN"
                        )
                    )

                    st.info("Request rejected.")

                    st.rerun()

    st.divider()

    # AUDIT TRAIL

    st.subheader("📜 Security Audit Trail")

    logs = get_recent_audit_logs(
        6,
        None if st.session_state.is_admin
        else student["student_id"]
    )

    for log in logs:

        status = log["status"]

        st.markdown(
            f'<span class="pill {status}">{status}</span> '
            f'**{log["action"]}**',
            unsafe_allow_html=True
        )

        st.caption(log["timestamp"][:19])

    st.divider()

    if st.button("Logout"):

        st.session_state.student = None
        st.session_state.messages = []
        st.session_state.is_admin = False

        st.rerun()


# MAIN DASHBOARD

st.title("SSSU Student Support Assistant")

st.caption(
    f"Welcome, {student['full_name']}"
)

chat_col, info_col = st.columns([2, 1])


# CHAT INTERFACE

with chat_col:

    st.subheader("💬 AI Student Assistant")

    for index, message in enumerate(
        st.session_state.messages
    ):

        with st.chat_message(message["role"]):

            st.markdown(message["content"])

            if (
                message["role"] == "assistant"
                and index in st.session_state.metrics
            ):

                metric = st.session_state.metrics[index]

                st.caption(
                    f"Latency: {metric['latency_seconds']} sec | "
                    f"Prompt tokens: {metric['prompt_tokens']} | "
                    f"Completion tokens: {metric['completion_tokens']} | "
                    f"Total tokens: {metric['total_tokens']}"
                )

                if metric["traces"]:

                    with st.expander(
                        "🔍 Execution Traces & Authorization Decision"
                    ):

                        st.json(metric["traces"])

    prompt = st.chat_input(
        "Ask your university-related question..."
    )

    if prompt:

        st.session_state.messages.append({
            "role": "user",
            "content": prompt
        })

        with st.chat_message("user"):

            st.markdown(prompt)

        with st.chat_message("assistant"):

            with st.spinner("Processing your request..."):

                try:

                    answer, metrics = run_agent_turn(
                        student,
                        st.session_state.messages
                    )

                except Exception as error:

                    answer = f"Error: {error}"

                    metrics = {
                        "latency_seconds": 0,
                        "prompt_tokens": 0,
                        "completion_tokens": 0,
                        "total_tokens": 0,
                        "traces": []
                    }

                st.markdown(answer)

                st.caption(
                    f"Latency: {metrics['latency_seconds']} sec | "
                    f"Total tokens: {metrics['total_tokens']}"
                )

                if metrics["traces"]:

                    with st.expander(
                        "🔍 Execution Traces",
                        expanded=True
                    ):

                        st.json(metrics["traces"])

        st.session_state.messages.append({
            "role": "assistant",
            "content": answer
        })

        index = len(st.session_state.messages) - 1

        st.session_state.metrics[index] = metrics

        if any(
            t["output"].get("status") == "REQUIRES_APPROVAL"
            for t in metrics["traces"]
        ):

            st.rerun()


# STUDENT INFORMATION PANEL

with info_col:

    st.subheader("Student Account")

    st.metric(
        "Fee Due",
        f"₹{student['fee_due']:,.0f}"
    )

    st.write(
        "**Fee Status:**",
        student["fee_status"]
    )

    st.write(
        "**Scholarship:**",
        student["scholarship_name"]
    )

    st.write(
        "**Scholarship Status:**",
        student["scholarship_status"]
    )

    st.divider()

    st.subheader("Quick Questions")

    suggestions = [
        "What is my fee status?",
        "What scholarships are available?",
        "Can I pay fees on the next working day if the payment portal fails?",
        "How can I update my registered bank?"
    ]

    for question in suggestions:

        if st.button(question, use_container_width=True):

            st.session_state.messages.append({
                "role": "user",
                "content": question
            })

            st.rerun()