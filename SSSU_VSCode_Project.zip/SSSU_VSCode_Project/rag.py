from pathlib import Path
from pypdf import PdfReader
import chromadb
from sentence_transformers import SentenceTransformer

PDF_PATH = "sssu_student_handbook.pdf"

client = chromadb.PersistentClient(
    path="./sssu_rag_data"
)

collection = client.get_or_create_collection(
    name="sssu_handbook"
)

model = None


def get_model():

    global model

    if model is None:
        model = SentenceTransformer(
            "sentence-transformers/all-MiniLM-L6-v2"
        )

    return model


def extract_handbook():

    reader = PdfReader(PDF_PATH)

    chunks = []

    for page_number, page in enumerate(reader.pages, start=1):

        text = page.extract_text() or ""

        paragraphs = text.split("\n")

        for paragraph in paragraphs:

            paragraph = " ".join(paragraph.split())

            if len(paragraph) > 30:

                chunks.append({
                    "page": page_number,
                    "text": paragraph
                })

    return chunks


def build_handbook_index(force_rebuild=False):

    global collection

    if force_rebuild:

        try:
            client.delete_collection("sssu_handbook")
        except Exception:
            pass

        collection = client.get_or_create_collection(
            name="sssu_handbook"
        )

    if collection.count() > 0:
        return collection.count()

    chunks = extract_handbook()

    if not chunks:
        raise ValueError("No handbook text found.")

    documents = [x["text"] for x in chunks]

    ids = [f"chunk_{i}" for i in range(len(chunks))]

    metadata = [
        {"page": x["page"]} for x in chunks
    ]

    embeddings = get_model().encode(
        documents,
        normalize_embeddings=True
    ).tolist()

    collection.add(
        ids=ids,
        documents=documents,
        metadatas=metadata,
        embeddings=embeddings
    )

    return len(chunks)


def query_handbook(query, n_results=2):

    if collection.count() == 0:
        build_handbook_index()

    embedding = get_model().encode(
        [query],
        normalize_embeddings=True
    ).tolist()

    result = collection.query(
        query_embeddings=embedding,
        n_results=min(n_results, collection.count())
    )

    excerpts = []

    for document, metadata in zip(
        result["documents"][0],
        result["metadatas"][0]
    ):

        excerpts.append(
            f"[Handbook Page {metadata['page']}]: {document}"
        )

    return "\n\n".join(excerpts)