import sqlite3
import hashlib
import secrets
import hmac
import json
from datetime import datetime, timezone

DB_PATH = "sssu_university.db"


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def now():
    return datetime.now(timezone.utc).isoformat()


def hash_password(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt, 310000
    )
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password, stored):
    try:
        salt, digest = stored.split("$")
        candidate = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt), 310000
        ).hex()
        return hmac.compare_digest(candidate, digest)
    except Exception:
        return False


def init_db():
    with connect() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS students (
            student_id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            program TEXT NOT NULL,
            fee_due REAL DEFAULT 45000,
            fee_status TEXT DEFAULT 'PENDING',
            scholarship_name TEXT,
            scholarship_status TEXT DEFAULT 'NOT_APPLIED',
            registered_phone TEXT,
            registered_bank TEXT
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            student_id TEXT,
            action TEXT,
            target_id TEXT,
            status TEXT,
            details TEXT,
            previous_hash TEXT,
            entry_hash TEXT
        );

        CREATE TABLE IF NOT EXISTS pending_actions (
            action_id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            student_id TEXT,
            action_type TEXT,
            proposed_value TEXT,
            status TEXT DEFAULT 'PENDING_APPROVAL',
            reviewed_at TEXT,
            reviewed_by TEXT
        );

        CREATE TRIGGER IF NOT EXISTS audit_no_update
        BEFORE UPDATE ON audit_logs
        BEGIN
            SELECT RAISE(ABORT, 'Audit records cannot be updated');
        END;

        CREATE TRIGGER IF NOT EXISTS audit_no_delete
        BEFORE DELETE ON audit_logs
        BEGIN
            SELECT RAISE(ABORT, 'Audit records cannot be deleted');
        END;
        """)

        # Seed demo account
        count = conn.execute(
            "SELECT COUNT(*) FROM students"
        ).fetchone()[0]

        if count == 0:
            conn.execute("""
                INSERT INTO students
                (student_id, username, password_hash, full_name,
                 program, fee_due, fee_status, scholarship_name,
                 scholarship_status, registered_phone, registered_bank)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                "SSSU-2026-001",
                "demo",
                hash_password("Demo@12345"),
                "Aarav Sharma",
                "Acharya",
                45000,
                "PENDING",
                "Acharya Shankara Merit Scholarship",
                "UNDER_REVIEW",
                "9876543210",
                "State Bank of India"
            ))


def log_audit(student_id, action, target_id, status, details):
    if status not in ["ALLOWED", "BLOCKED", "PENDING_APPROVAL"]:
        raise ValueError("Invalid audit status")

    with connect() as conn:
        previous = conn.execute(
            "SELECT entry_hash FROM audit_logs ORDER BY id DESC LIMIT 1"
        ).fetchone()

        previous_hash = (
            previous["entry_hash"] if previous else "GENESIS"
        )

        timestamp = now()

        payload = json.dumps([
            timestamp, student_id, action, target_id,
            status, str(details), previous_hash
        ], separators=(",", ":"))

        entry_hash = hashlib.sha256(
            payload.encode()
        ).hexdigest()

        conn.execute("""
            INSERT INTO audit_logs
            (timestamp, student_id, action, target_id,
             status, details, previous_hash, entry_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            timestamp, student_id, action, target_id,
            status, str(details)[:4000],
            previous_hash, entry_hash
        ))


def register_student(student_id, username, password,
                     full_name, program, phone):

    if len(password) < 10:
        raise ValueError("Password must have at least 10 characters")

    with connect() as conn:
        conn.execute("""
            INSERT INTO students
            (student_id, username, password_hash,
             full_name, program, registered_phone,
             fee_due, fee_status, scholarship_name,
             scholarship_status)
            VALUES (?, ?, ?, ?, ?, ?, 45000,
                    'PENDING',
                    'Acharya Shankara Merit Scholarship',
                    'NOT_APPLIED')
        """, (
            student_id,
            username.lower().strip(),
            hash_password(password),
            full_name,
            program,
            phone
        ))

    log_audit(student_id, "REGISTRATION", student_id,
              "ALLOWED", "New student registered")


def authenticate_student(username, password):

    with connect() as conn:
        user = conn.execute(
            "SELECT * FROM students WHERE username=?",
            (username.lower().strip(),)
        ).fetchone()

    if user and verify_password(password, user["password_hash"]):
        result = dict(user)
        result.pop("password_hash", None)

        log_audit(
            result["student_id"], "LOGIN",
            result["student_id"], "ALLOWED",
            "Successful login"
        )

        return result

    log_audit(None, "LOGIN", username, "BLOCKED",
              "Invalid login attempt")

    return None


def get_student_by_id(student_id):

    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM students WHERE student_id=?",
            (student_id,)
        ).fetchone()

    if not row:
        return None

    result = dict(row)
    result.pop("password_hash", None)

    return result


def get_recent_audit_logs(limit=15, student_id=None):

    with connect() as conn:
        if student_id:
            rows = conn.execute("""
                SELECT * FROM audit_logs
                WHERE student_id=?
                ORDER BY id DESC LIMIT ?
            """, (student_id, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT * FROM audit_logs
                ORDER BY id DESC LIMIT ?
            """, (limit,)).fetchall()

    return [dict(row) for row in rows]


def create_pending_action(student_id, action_type, proposed_value):

    with connect() as conn:
        cursor = conn.execute("""
            INSERT INTO pending_actions
            (timestamp, student_id, action_type,
             proposed_value, status)
            VALUES (?, ?, ?, ?, 'PENDING_APPROVAL')
        """, (
            now(), student_id, action_type, proposed_value
        ))

        return cursor.lastrowid


def get_pending_actions():

    with connect() as conn:
        rows = conn.execute("""
            SELECT p.*, s.full_name
            FROM pending_actions p
            LEFT JOIN students s
            ON p.student_id=s.student_id
            WHERE p.status='PENDING_APPROVAL'
            ORDER BY p.action_id
        """).fetchall()

    return [dict(row) for row in rows]


def review_pending_action(action_id, decision, reviewer="ADMIN"):

    decision = decision.upper()

    if decision not in ["APPROVED", "REJECTED"]:
        raise ValueError("Invalid decision")

    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM pending_actions WHERE action_id=?",
            (action_id,)
        ).fetchone()

        if not row or row["status"] != "PENDING_APPROVAL":
            raise ValueError("Request already reviewed or not found")

        if decision == "APPROVED":
            proposal = json.loads(row["proposed_value"])
            attribute = row["action_type"]

            if attribute not in ["registered_phone", "registered_bank"]:
                raise ValueError("Invalid profile attribute")

            conn.execute(
                f"UPDATE students SET {attribute}=? WHERE student_id=?",
                (proposal["new_value"], row["student_id"])
            )

        conn.execute("""
            UPDATE pending_actions
            SET status=?, reviewed_at=?, reviewed_by=?
            WHERE action_id=?
        """, (decision, now(), reviewer, action_id))

    log_audit(
        row["student_id"],
        "PROFILE_UPDATE_" + decision,
        row["student_id"],
        "ALLOWED" if decision == "APPROVED" else "BLOCKED",
        f"Request {action_id} reviewed"
    )


def verify_audit_chain():

    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_logs ORDER BY id"
        ).fetchall()

    previous = "GENESIS"

    for row in rows:
        if row["previous_hash"] != previous:
            return False

        payload = json.dumps([
            row["timestamp"], row["student_id"],
            row["action"], row["target_id"],
            row["status"], row["details"],
            row["previous_hash"]
        ], separators=(",", ":"))

        expected = hashlib.sha256(payload.encode()).hexdigest()

        if expected != row["entry_hash"]:
            return False

        previous = row["entry_hash"]

    return True