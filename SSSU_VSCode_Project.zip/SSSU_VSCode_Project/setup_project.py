from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
from database import init_db
from memory import init_memory_db

styles = getSampleStyleSheet()
title_style = ParagraphStyle("UniversityTitle", parent=styles["Title"], alignment=TA_CENTER, textColor=colors.HexColor("#17365D"))
story = [Paragraph("Satya Sanatan Sanskrit University (SSSU)", title_style), Spacer(1, 20)]
content = [
    ("1. Tuition and Programs", "The illustrative standard tuition fee is ₹45,000 per semester for Shastri, Acharya and PGDM programs."),
    ("2. Fee Payment", "Students must pay their fees through the university's approved payment channels and retain transaction receipts."),
    ("2.2 Payment Gateway Failure", "If an institutional or banking payment gateway experiences technical failure on the scheduled fee deadline, students are granted an automatic grace period extending to 11:59 PM on the subsequent working day with no late penalties."),
    ("3. Scholarships", "Acharya Shankara Merit Scholarship is an illustrative merit-based scholarship. Maharshi Panini Need-Based Scholarship is an illustrative financial assistance program."),
    ("4. Student Profile", "Students must keep their contact and banking information updated. Profile changes require administrative verification."),
    ("5. Student Support", "Students may contact the appropriate university department for fee, scholarship and academic assistance."),
    ("6. Data Privacy and Security", "Student records are confidential. Students may access only their own records. Peer records must never be disclosed. Profile changes require administrative verification. OTPs, passwords and PINs must never be retained in long-term memory.")
]
for heading, paragraph in content:
    story.extend([Paragraph(heading, styles["Heading2"]), Paragraph(paragraph, styles["BodyText"]), Spacer(1, 12)])
story.extend([Spacer(1, 20), Paragraph("<b>Note:</b> This is demonstration policy content created for the academic software project. It is not an approved or legally binding university handbook.", styles["BodyText"])])
SimpleDocTemplate("sssu_student_handbook.pdf", pagesize=A4).build(story)
init_db()
init_memory_db()
print("Setup complete: handbook PDF and demo databases created.")
